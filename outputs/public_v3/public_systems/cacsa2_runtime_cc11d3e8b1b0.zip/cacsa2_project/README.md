# cacsa2 — analysis code for the CACSA polarity study

Code for the CACSA manuscript in preparation (constraint-aware cross-sentence attention; negation and scope),
K. Kotan, Manisa Celal Bayar University. The title is fixed only after the confirmatory results are final.

* `cacsa2/` — package (data, encoders, scope resolver, model with aggregators A1–A5, training, metrics, statistics, controls, analysis, provenance).
* `tests/test_model.py` — unit tests, including the token-addition monotonicity of `max`/`lse`, the non-monotonicity of `mean`,
  the veto behaviour of `signed_max`, padding invariance and identical core parameter counts across aggregators.
* `tests/test_scope.py` — scope resolver: termination on root-without-verb fragments, expected scopes, mask alignment.
* `tests/test_negpairs_build.py` — construction filters (v1 defects, v2 fixes) on real first-run outputs.
* `tests/test_negpairs.py` — NegPairs helpers: cue and decisive spans, dataset-supplied mask, sentence diagnostics,
  paired metrics, context-blindness of the option-only control.
* `CACSA_v2_main_experiment_colab.ipynb` — CondaQA grid under manifest v1.1 (archived as an optimization/validity failure).
* `CACSA_v11_followup_colab.ipynb` — float64 re-check of the v1.1 Proposition-1 test; C1 re-execution in float32.
* `NegPairs_build_colab.ipynb` — builds the NegPairs minimal-pair dataset, construction v2 (model-generated, blind model
  verification); `NegPairs_build_colab_v1.ipynb` is the archived first-run builder.
* `NegPairs_pilot_colab.ipynb` — pilot on NegPairs train/dev only (data audit, resolver report, Proposition 1, lr, A1 learnability).
* `NegPairs_main_colab.ipynb` — confirmatory NegPairs run under manifest v2.0 (frozen; `CACSA_manifest_v2_0.md`).
* `NegPairs_v3_build_colab.ipynb` — builds NegPairs-Perm (permutation minimal pairs) and NegPairs-Fresh (new test set)
  under manifest v3.0 (frozen; `CACSA_manifest_v3_0.md`): Claude generation and Haiku verification, Qwen2.5-7B-Instruct
  as a second verifier (both option orders), acceptance in schedule order, Opus audit. GPU runtime (L4 or A100).
* `data/negpairs_v1/` — NegPairs v1 (construction v2, 1,088 scenarios) with its build record and file manifest.
* `NegPairs_v3_main_colab.ipynb` — extended experiment of manifest v3.0: pilot on train/dev (exact checks with random
  initializations, C1 check, learning rate per encoder), 7 encoders x 8 conditions x 10 seeds plus controls with 4 worker
  processes on one GPU, dev gate, exact rules R5/R6/R7 in float64, NevIR, rules R2/R3/R8, probing, Qwen audit of v1.
* `NegPairs_v3_followup_colab.ipynb` — float64 Perm predictions for the static encoders after the main run (CPU, 10 min).
* `NegPairs_public_systems_colab.ipynb` — revision step 1 (October 2026): public retrieval systems as released (late
  interaction: ColBERTv2, answerai-colbert-small, GTE-ModernColBERT (PyLate format, scored without the library), bge-m3 three heads; dense: bge-base, e5-base,
  all-mpnet, gte-modernbert; SPLADE; cross-encoders and monoT5; pointwise LLM judges Phi-4-mini, OLMo-2-7B, Qwen3-8B,
  Llama-3.1-8B; optional API pairwise judge on NevIR) scored on NegPairs-Perm, NegPairs-Fresh and NevIR through their
  own interfaces (`cacsa2/public_systems.py`), with the article's metrics and intervals. A100 or L4 runtime.
* `negpairs_v3_audit.md` — audit of the delivered NegPairs-Perm and NegPairs-Fresh files (6 October 2026).
* `np_v3_main_audit.md` — audit of the delivered np_v3_main run and of the float64 follow-up (7 October 2026).
* `indep/` — independent recomputation of every reported metric from the raw predictions (`recompute_v3.py`,
  `recompute_f64.py`) with their reports.
* `paper/` — the manuscript pipeline: number registry built from the archived outputs, English and Turkish
  templates, tables and figures, docx build, digit-level verification, claim checks, traceability tables, the
  verified reference list and the internal critical review with responses (see `paper/README.md`).
* `make_*.py` — regenerate the notebooks.

Run tests: `python tests/test_model.py`, `python tests/test_scope.py`, `python -m unittest tests.test_negpairs tests.test_negpairs_build` (spaCy `en_core_web_sm` needed for the scope and negpairs tests). Data (CondaQA) is not redistributed; the notebook clones it from GitHub at a pinned commit.
License: MIT.

## Change log
* 0.3.4 (2026-10-22): `public_systems`: the decisive logits of monoT5 and of the pointwise LLM judges are computed in float32
  from the pre-head state (bfloat16 logits tied near-identical documents); GTE-ModernColBERT scored by a replication of
  the PyLate encoding (`STColBERT`, no library); notebook mounts Drive first, installs nothing, `RESCORE` option.
* 0.3.3 (2026-10-21): `public_systems` module and `NegPairs_public_systems_colab.ipynb` (public systems on Perm, Fresh and
  NevIR with their own interfaces; re-implemented bge-m3 heads checked against the reference implementation at run time;
  resumable; failures recorded). No change to the experiment code of manifest v3.0.
* 2026-10-07 (no package change): `paper/` added (manuscript pipeline of the v3.0 article, internal review
  and responses), `indep/` reports and `np_v3_main_audit.md` included.
* 0.3.2 (2026-10-07): `NegPairs_v3_followup_colab.ipynb`: float64 NegPairs-Perm predictions for E0 and E3 from the archived
  module states (manifest v3.0, section 10), Perm tables of the static encoders recomputed from them, differences listed.
* 0.3.1 (2026-10-07): experiment code of manifest v3.0. Encoders E3 (`GloveEncoder`), E6 (`ColBERTDocEncoder`,
  checkpoint projection), per-call length limit; `model.MaxSimModule` (M1), `model.ZeroShotMaxSim` (M0), `make_module`;
  `colbert.ColBERTNative` (M0-native); Perm-aware oracle masks and diagnostics from the stored clause spans; `np_analysis_v3`
  (permutation estimands, SS_perm_bal, dev gate, rules with the four conditions at level 1 - 0.05/k, order-stratified
  bootstrap); `exact` (R5/R6/R7 in float64, pilot checks); `nevir`; `probing` (neutral twins, A5 gate AUC); `packs` and
  `worker` (encoder packs, spawn-based training workers, `done.json` markers, resume); C1 archives raw predictions on extra
  test sets without computing metrics; `qwen_verify` records the snapshot revision from the cache. Tests:
  `tests/test_v3_analysis.py`. Offline harness (not shipped) ran the notebook end to end with fakes for every download.
* 0.3.0 (2026-10-05): manifest v3.0 frozen (`CACSA_manifest_v3_0.md`). New modules `perm_prompts` (frozen prompts and
  their SHA-256), `perm_build` (Perm schedule with a balanced clause order, deterministic assembly of O, N and S from the
  marked context, the eleven filters, item files with clause, cue and W spans), `qwen_verify` (forced choice from
  float32 letter logits, both option orders), `build_v3` (metered calls with phase caps, batches, acceptance in schedule
  order with near-duplicate check and caps, resume, safety stop, Opus audit). Tests: `tests/test_perm_build.py`,
  `tests/test_qwen_verify.py` (tiny random Qwen2 model; logits with left padding equal the unpadded forward pass).
  NegPairs v1 is shipped in `data/negpairs_v1/`.
* 0.2.5 (2026-10-04): manifest v2.0 frozen (`CACSA_manifest_v2_0.md`, shipped in the package; the confirmatory
  notebook copies it into the run folder and records its SHA-256 before training). Primary estimand: scope
  sensitivity SS = flip_O_N - flip_O_S (`negpairs.scenario_flips`, `cue_lemma`; `np_analysis.cluster_bootstrap_flip`,
  `evaluate_rules_flip`); the draft-1 accuracy rules are kept as `evaluate_rules_accuracy` (secondary). Per-run
  S-same decision changes and a same-cue analysis for "not". Main notebook pinned to pilot `np_pilot_20261004T143238Z`.
* 0.2.4 (2026-10-03): NegPairs construction v2 (`negpairs_build`: `structural_filter_v2`, `VERIFY_PROMPT_V2`,
  `verify_arms_v2`, `check_and_verify_v2`, `process_v2`; generation prompt unchanged). The first build kept 7% of
  1,416 candidates; the record showed generator responses cut off by thinking (1,200-token limit), a substring test
  for "cue already present" ("no" matched "notebook"), names counted as new when they changed position or took a
  possessive, an N edit limit (3 words) below most natural negations, and verifier wording that rejected clear items.
  The v2 builder notebook re-checks the first run's candidates under v2 (verifier calls only), generates the rest at
  effort low with a 4,000-token limit, stops at a session budget and on exhausted credit, and keeps the first run's
  record unchanged (`build_state_v1_backup.json`). `tests/test_negpairs_build.py` uses real first-run outputs.
* 0.2.3 (2026-10-03): `encoders.hf_load_report` (tokenizer unknown-token rate, example tokenization, missing /
  unexpected weight keys as reported by `from_pretrained`); the pilot notebook runs it for E1, E2 and the C1 head and
  adds a short C1 fine-tuning check on dev. Notebooks extract the package into a fresh folder per zip hash, drop any
  previously imported `cacsa2` modules, and check the version before importing submodules (a stale Drive zip produced
  `ImportError: cannot import name 'negpairs_build'`).
* 0.2.2 (2026-10-03): control C2 (option-only, context-blind) and a learnability gate that requires A1 to beat it;
  paired metrics (accuracy on P/S/N given a correct O item; both O and N correct); per-item cue, scope and sentence
  diagnostics against the generator's decisive words, and the S-same subset (cue and decisive words in one sentence)
  on which rule R3 is evaluated; dataset-supplied polarity (`signed_max_oracle`) as a descriptive upper bound;
  `ScopeResult.sentences`. The cue lexicon and scope rules are unchanged since 0.1.1 (comment on -less words corrected).
* 0.2.1 (2026-10-03): `negpairs` (loading, items, arm metrics, insertion pairs, multiple-choice fine-tuning reference),
  `np_analysis` (gate, rules, cluster bootstrap, McNemar), sentence-wide polarity mask (scope-blind control A6),
  optional L2 normalization of frozen token states (as in the archived CACSA v2 notebook), pilot and main notebooks.
* 0.2.0 (2026-10-03): `negpairs_build` and the dataset-builder notebook.
* 0.1.2 (2026-10-03): control C1 loads weights explicitly in float32 (transformers 5 otherwise keeps the checkpoint's
  half precision; every C1 step of the v1.1 run was NaN) and aborts on any non-finite loss; `cacsa2.prop1` runs the
  Proposition-1 test in float64 on CPU (the v1.1 GPU test used TF32 matmuls with a 1e-5 tolerance);
  `CACSA_v11_followup_colab.ipynb` re-checks the v1.1 Proposition-1 test and re-executes C1.
* 0.1.1 (2026-10-03): fixed a non-terminating loop in the scope resolver (`_verbal_ancestor` compared spaCy tokens by
  identity; spaCy returns a new Token object on every access, so a sentence root that is not a verb was never recognised).
  Added text-level caching and batched parsing (`ScopeResolver.prefetch`), a collision-free polarity-mask cache key,
  `tests/test_scope.py`, a vectorized passage-cluster bootstrap, `dtype=` loading for current transformers, local-disk
  token caches and full-fine-tuning weights (never on Drive), pinned CondaQA commit with file-hash check, progress/ETA output.
* 0.1.0 (2026-10-02): first version.
